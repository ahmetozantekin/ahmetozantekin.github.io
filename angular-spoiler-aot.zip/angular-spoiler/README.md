# angular-spoiler-js

Spoiler alert tag for AngularJS 
[Visit the page](https://ahmetozantekin.github.io/angular-spoiler)
#### Usage.
```html
   
  <p>Suspect Verbal Kint was <spoiler>Keyser Söze</spoiler> since in the beginning.</p>
   
```

![alt tag](http://watchersonthewall.com/wp-content/uploads/2016/09/spoiler.gif)