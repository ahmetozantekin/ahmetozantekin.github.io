angular.module('spoiler', [
	'angular-spoiler'
]);


